import React from 'react';
//import {Link} from 'react-router-dom';
import {NavLink} from 'react-router-dom';

const NavLinkComponent =()=>{
 
        return(
            // <ul className="list-group">
            //     {/* <li><Link className="active" to="/"> Home </Link></li>
            //     <li><Link to="/about"> About </Link> </li> */}

            //     <li><NavLink activeClassName="active" exact to="/" className="list-group-item"> Home </NavLink></li>
            //     <li><NavLink activeClassName="active" to="/about" className="list-group-item"> About </NavLink> </li>
            //     <li><NavLink activeClassName="active" to="/content" className="list-group-item"> Content </NavLink> </li>

            // </ul>
            <div className="list-group">
                <li><NavLink activeClassName="active" exact to="/" className="list-group-item"> Home </NavLink></li>
                <li><NavLink activeClassName="active" to="/about" className="list-group-item"> About </NavLink> </li>
                <li><NavLink activeClassName="active" to="/content" className="list-group-item"> Content </NavLink> </li>
    
            </div>
        );
    
    
}

export default NavLinkComponent;
