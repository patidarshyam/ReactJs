import React from 'react';

class AboutComponent extends React.Component{
    render() {
        return(
            <h1>About Page</h1>
        );
    }
    
}

export default AboutComponent;