import React from 'react';

class HomeComponent extends React.Component{
    render() {
        return(
            <h1>Home Page</h1>
        );
    }
    
}

export default HomeComponent;