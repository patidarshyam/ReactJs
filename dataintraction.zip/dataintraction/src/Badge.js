import React from 'react';

const Badge=(props)=>{
    return(
        <div className="container" style={{width:'300px', margin:'10px',border:'1px solid black'}}>
            <div  style={{display:'inline-block'}}>
                <img style={{margin:'10px',width:'75px'}} src={props.avatar_url} />
                <div className="userDetailSection"  style={{float:'right',margin:'20px'}}>
                    <div style={{fontSize:'20px',fontWeight:'bold'}} >
                    {props.name}
                    </div>
                    <div  >
                    {props.company}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Badge;