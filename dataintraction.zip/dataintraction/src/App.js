import React ,{Component} from 'react';
import BadgeForm from './BadgeForm';
import BadgeList from './BadgeList';

class App extends Component{
    state={
        data:[
          
        ]
    }

    addNewBadge=(badgeInfo)=>{
        this.setState({
            data:this.state.data.concat(badgeInfo)
        });
    }

    render(){
        return(
            <div style={{margin:'20px'}}>
                <BadgeForm onSubmit={this.addNewBadge}/>
                <hr/>
                <BadgeList badges={this.state.data}/>
            </div>
        );
    }
}
export default App;