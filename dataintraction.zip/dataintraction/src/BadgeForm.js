import React from 'react';
import axios from 'axios';

class BadgeForm extends React.Component{
    state={userName:''}
    updateUserName=(event)=>{
        this.setState({
            userName:event.target.value
        })
    }

    handleSubmit=(event)=>{
        event.preventDefault();
        console.log('Button clicked',this.state.userName);
        //AJAX Call: JQuery, fetch,axios
        //fetch use
        // fetch(`https://api.github.com/users/${this.state.userName}`)
        // .then(function(res){
        //     console.log(res.json());
        // })

        //axios use
       axios(`https://api.github.com/users/${this.state.userName}`)
        .then(res=>{
           console.log(res);
           this.props.onSubmit(res.data);
        })
    }
    render(){
        return(
            <div style={{margin:'10px'}}>
                <form onSubmit={this.handleSubmit}>       
                    <input type="text"
                   onChange={this.updateUserName}
                     placeholder="GitHub username"/>
                    <button>Add</button>
                </form>
            </div>
        );
    }
}
export default BadgeForm;