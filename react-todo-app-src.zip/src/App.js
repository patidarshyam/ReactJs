import React, { Component } from 'react';
import './App.css';
import HeaderComponent from './HeaderComponent';
import TodoListComponent from './components/common/TodoListComponent';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import RaisedButton from 'material-ui/RaisedButton'
class App extends Component {
  render() {
    return (
      <div id="container">
        <div id="header">
          <HeaderComponent />
        </div>
        <div id="main">
        {/* <MuiThemeProvider>
        <RaisedButton label="Primary" primary={true}  />
        </MuiThemeProvider> */}
          <TodoListComponent/> 
      </div>
      <div id="footer">
       footer
      </div>
      </div>
    );
  }
}

export default App;
