import React, { Component } from 'react';
import LogoComponent  from './LogoComponent'

class HeaderComponent extends Component {

  constructor(props){
    super(props);
    this.state={
      headerText:'TODO-APP using ReactJS'
    };
  }

  render() {
    return (
      <div>
     <h1>{this.state.headerText}</h1>
     <LogoComponent logo="TODO-APP" />
     </div>
    );
  }
}

export default HeaderComponent;