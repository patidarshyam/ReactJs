import React from 'react';
import PropTypes from 'prop-types'; // ES6

import TodoTextComponent from './TodoTextComponent';
import TodoFormComponent from './TodoFormComponent';

class TodoListComponent extends React.Component{
    constructor(props){
        super(props);
        this.state={
            todos:[
                {todoText:'Create TODO', completed:false},
                {todoText:'Update TODO', completed:false},
                {todoText:'Delete TODO', completed:false}
                ],
            currentTodo:''
        };
        this.changeTodo=this.changeTodo.bind(this);
        this.updateTodo=this.updateTodo.bind(this);
        this.addTodo=this.addTodo.bind(this);
        this.deleteTodo=this.deleteTodo.bind(this);
        this.editTodo=this.editTodo.bind(this);
    }

    editTodo(position,newValue){
       
        let todos=this.state.todos;
        let todoUpdate=todos[position];
        todoUpdate.todoText=newValue;
        this.setState({
            todos
        });
    }

    addTodo(event){
        event.preventDefault();
        let todos=this.state.todos;
        let currentTodo=this.state.currentTodo;
        todos.push({
            todoText:currentTodo,
            completed:false
        });

        this.setState({
            todos,
            currentTodo:''
        });

    }

    deleteTodo(todoToBeDeleted){
      let todos=this.state.todos;
       todos.splice(todoToBeDeleted,1);
       this.setState({
        todos
       });
    }
    updateTodo(event){
        this.setState({
            currentTodo:event.target.value
        }) 
    }

    changeTodo(index){
        let todos=this.state.todos;
        let todo=todos[index];
        todo.completed=!todo.completed;
        this.setState({
            todos
        });
        console.log(this.state.todos[index]);
    }

    render(){
        return(
            <section>
                <TodoFormComponent 
                    currentTodo={this.state.currentTodo}
                    updateTodo={this.updateTodo}
                    addTodo={this.addTodo}
                    
                />
            <ul>
            {
                this.state.todos.map((todo,index)=>{
                    return <TodoTextComponent 
                    key={todo.todoText}
                     todo={todo}
                     index={index}
                     deleteTodo={this.deleteTodo}
                     editTodo={this.editTodo}
                     clickHandler={this.changeTodo}/>
                    
                })
            }
            </ul>
            </section>
        );
    }
}
TodoTextComponent.propTypes={
    todo:PropTypes.object,
    index:PropTypes.number,
    deleteTodo:PropTypes.func,
    editTodo:PropTypes.func,
    clickHandler:PropTypes.func
}
export default TodoListComponent;