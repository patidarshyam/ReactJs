import React from 'react';

// const TodoTextComponent =(props)=>{
//     return(
//         <ul>
//         <li onClick={()=>{props.clickHandler(props.index)}}
//         className={props.todo.completed===true?'completed':''}>
//             {props.todo.todoText}

//             <button id="deleteButton" onClick={(event)=>{
//                 event.stopPropagation();
//                 props.deleteTodo(props.index)
//             }
//             }>X</button>

//             <button id="editButton" >Edit</button>

//         </li>

//     </ul>
//     );
// }
// export default TodoTextComponent;

class TodoTextComponent extends React.Component{

    constructor(props){
        super(props);
        this.state={
            isEditing:false
        },
        this.updateTodo=this.updateTodo.bind(this);
        this.toggleIsEdditing=this.toggleIsEdditing.bind(this);
    }

   
    updateTodo(event){
        console.log('updatetodo method....')
        event.preventDefault();
        this.toggleIsEdditing();
        this.props.editTodo(this.props.index,this.input.value);
      }

    toggleIsEdditing(){
        this.setState({
            isEditing:!this.state.isEditing
        });
    }

    renderEditForm(){
        return(
            <form id="updateForm">
                <input type="text" 
                defaultValue={this.props.todo.todoText}
                ref={(value) => { this.input = value }}
                 />
                <button type="submit" onClick={(event)=>this.updateTodo(event)}>Update</button>
            </form>
        );
    }

    renderTodoText(){
        return(
            <ul>
            <li onClick={()=>{this.props.clickHandler(this.props.index)}}
            className={this.props.todo.completed===true?'completed':''}>
                {this.props.todo.todoText}
                <button id="deleteButton" onClick={(event)=>{
                    event.stopPropagation();
                    this.props.deleteTodo(this.props.index)
                }
                }>X</button>
                 <button id="editButton" onClick={(event)=>{
                     event.stopPropagation();
                     this.toggleIsEdditing(); 
                }} >Edit</button>
            </li>
    
        </ul>
        )
    }
    
    render(){
        //const isEditing=this.state.isEditing;
        const {isEditing}=this.state;
        return(
        <section>
           {isEditing ? this.renderEditForm() : this.renderTodoText()}
        </section>
        );
    }
}
export default TodoTextComponent;