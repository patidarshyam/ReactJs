import React from 'react';

const LogoComponent=function(props){
    return(
        <h2>{props.logo}</h2>
    );
}
export default LogoComponent;